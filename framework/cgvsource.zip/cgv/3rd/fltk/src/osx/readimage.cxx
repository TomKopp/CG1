uchar *fltk::readimage(uchar *p, PixelType type, const Rectangle&, int linedelta) {
  return 0;
}
